package com.project.bankmanag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankmanagApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankmanagApplication.class, args);
	}

}
